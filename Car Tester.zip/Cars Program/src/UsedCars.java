public class UsedCars extends Car {
	private int Mileage;
	
	public UsedCars(double Price, int Mileage) {
		super(Price);
		// Notice the use of the "this" keyword again
		this.Mileage = Mileage;
	}
	
	/*
	 * setters and getters
	 */
	public int getMileage() {
		return Mileage;
	}
	
	
	public void setMileage(int Mileage) {
		this.Mileage = Mileage;
	}
	
	/*
	 * equals method to test for the equality of two objects
	 */
	public boolean equals(UsedCars usedCar2) {
		boolean objectsEqual;
		/*
		 * Notice the use of "this" again.
		 * "this" refers to the object calling the equals method.
		 */
		boolean condition1 = this.getPrice() == (usedCar2.getPrice());
		// Remember that the String class has its own built-in equals method.
		boolean condition2 = (this.getMileage() == usedCar2.getMileage());
		if (condition1 && condition2) {
			objectsEqual = true;
		} else {
			objectsEqual = false;
		}
		return objectsEqual;
	}
}
