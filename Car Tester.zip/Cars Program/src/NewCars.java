public class NewCars extends Car {
	private String Color;
	
	public NewCars(double Price, String Color) {
		super(Price);
		// Notice the use of the "this" keyword again
		this.Color = Color;
	}
	
	/*
	 * setters and getters
	 */
	public String getColor() {
		return Color;
	}
	
	
	public void setColor(String Color) {
		this.Color = Color;
	}
	
	/*
	 * equals method to test for the equality of two objects
	 */
	public boolean equals(NewCars newCar2) {
		boolean objectsEqual;
		/*
		 * Notice the use of "this" again.
		 * "this" refers to the object calling the equals method.
		 */
		boolean condition1 = this.getPrice() == (newCar2.getPrice());
		// Remember that the String class has its own built-in equals method.
		boolean condition2 = (this.getColor().equals (newCar2.getColor()));
		if (condition1 && condition2) {
			objectsEqual = true;
		} else {
			objectsEqual = false;
		}
		return objectsEqual;
	}
}