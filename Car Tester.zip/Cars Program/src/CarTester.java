
public class CarTester {

	public static void main(String[] args) {
		UsedCars Toyota = new UsedCars(10000.0, 600);
		
		UsedCars Honda = new UsedCars(10000.0, 600);
		
		NewCars Audi = new NewCars(45000.0, "White");
		
		NewCars Subaru = new NewCars(45000.0, "White");
		
		if(Toyota.equals(Honda)) {
			Toyota.getMileage();
			Toyota.getPrice();
			System.out.println("Toyota Price: $" + Toyota.getPrice());
			System.out.println("Toyota Mileage: " + Toyota.getMileage());
			System.out.println();
			Honda.getMileage();
			Honda.getPrice();
			System.out.println("Honda Price: $" + Honda.getPrice());
			System.out.println("Honda Mileage: " + Honda.getMileage());
			System.out.println();
		}
		
		if(Audi.equals(Subaru)) {
			Audi.getColor();
			Audi.getPrice();
			System.out.println("Audi Price: $" + Audi.getPrice());
			System.out.println("Audi Color: " + Audi.getColor());
			System.out.println();
			Subaru.getColor();
			Subaru.getPrice();
			System.out.println("Subaru Price: $" + Subaru.getPrice());
			System.out.println("Subaru Color: " + Subaru.getColor());
			System.out.println();
			
		}	
	}
}
