public abstract class Car {
	private double Price;
	public Car(double Price) {
		this.Price = Price;
	}
	
	/*
	 * getters and setters
	 */
	public double getPrice() {
		return Price;
	}
	
	public void setPrice(double Price) {
		this.Price = Price;
	}
}
